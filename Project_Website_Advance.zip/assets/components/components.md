Lưu file tái sử dụng
