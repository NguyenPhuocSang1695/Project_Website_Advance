Lưu hình ảnh
