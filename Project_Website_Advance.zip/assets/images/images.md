Lưu hình ảnh
