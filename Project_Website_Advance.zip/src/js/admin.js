//menu profile
let profile = document.querySelector(".profile");
let thongbao = document.querySelector(".thongbao");


profile.addEventListener("click", ()=>{
    thongbao.classList.toggle("active")
})  